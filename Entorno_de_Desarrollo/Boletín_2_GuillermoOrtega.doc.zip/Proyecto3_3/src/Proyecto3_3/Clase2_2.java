package Proyecto3_3;

import java.util.Scanner;

public class Clase2_2 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Practica3_3 " + "Guillermo " );

	}

}
